<?php

	/**
	*
	*	@author: Kevin
	*	@package: sys
	*
	*	Model: Les funcions que es realitzen a model.php
	*	serveixen per tractar les dades que rebem de la base de dades
	*
	**/

	namespace X\Sys;

	class Model{

		protected $db;
		protected $stmt;

		public function __construct(){
			$this->db=DB::singleton();
		}

		public function query($query){
    		$this->stmt = $this->db->prepare($query);
		}
		
		public function bind($param, $value){
    	
	        switch (true) {
	            case is_int($value):
	                $type = \PDO::PARAM_INT;
	                break;
	            case is_bool($value):
	                $type = \PDO::PARAM_BOOL;
	                break;
	            case is_null($value):
	                $type = \PDO::PARAM_NULL;
	                break;
	            default:
	                $type = \PDO::PARAM_STR;
	        	}
	    	
	    	$this->stmt->bindValue($param, $value, $type);
	}
	public function execute(){
		$result=$this->stmt->execute();
    	return $result;
	}
	public function resultset(){
    	
		return $this->stmt->fetchAll(\PDO::FETCH_ASSOC);
	}
	public function single(){
	    
	    return $this->stmt->fetch(\PDO::FETCH_ASSOC);
	}
	public function rowCount(){
	    return $this->stmt->rowCount();
	}
	public function lastInsertId(){
    	return $this->db->lastInsertId();
	}
	public function beginTransaction(){
		echo "Inicio Transaccion<br>";
	    return $this->db->beginTransaction();
	}
	public function endTransaction(){
		echo "Final Transaccion<br>";
	    return $this->db->commit();
	}
	public function cancelTransaction(){
	    return $this->db->rollBack();
	}
	public function debugDumpParams(){
	    return $this->stmt->debugDumpParams();
	}
	}