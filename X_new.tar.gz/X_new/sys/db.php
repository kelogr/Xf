<?php

	namespace X\Sys;

	/**
	*  author: Kevin
	*/

	class DB extends \PDO //Es una libreria fuera del framework, por eso ponemos la \
	{
		static $instance;

		function __construct()
		{
			$config=Registry::getInstance();
			$dbconf=(array)$config->dbconf; //EN db conf tenim un array de la configuracio
			$dsn=$dbconf['driver'].':host='.$dbconf['dbhost'].';dbname='.$dbconf['dbname'];
		 	$usr=$dbconf['dbuser'];
		 	$pwd=$dbconf['dbpass'];
			parent::__construct($dsn,$usr,$pwd);

		}

		static function singleton(){ //només accepta una conexió
			if(!(self::$instance instanceof self)){ //Si no es una instancia la instancia que creidem i es falsa
				self::$instance = new self();
			}
				return self::$instance;
		}
	}