<?php
	namespace X\Sys;

	use X\Sys\Registry;
	/**
	*
	*   Controller: the base controller
	*     in MVC systems
	*
	*
	*
	**/
	class Controller{
		protected $model;
		protected $view;
		protected $params;
		protected $dataView=array();
		protected $dataTable=array();
		protected $conf;
		protected $app;

		function __construct($params=null,$dataView=null){
			$this->params=$params;
			$this->conf=Registry::getInstance();
			$this->app=(array)$this->conf->app;
			$this->addData($this->app);
		}

		protected function addData($array){
			if (is_array($array)){
				if ($this->is_single($array)&& is_array($this->dataView)){
					$this->dataView=array_merge($this->dataView,$array);
					/*var_dump($this->dataView);
					var_dump($this->dataTable);*/
				}else{
					$this->dataTable=$array;
				}
			}
			else{
				$this->dataView=$array;
			}
		}

		protected function multipleData($mdata){
			//
			for($i=0;$i<count($mdata);$i++){
				foreach ($mdata[$i] as $key => $value) {
					$result[$key.$i]=$value;
				}
			}
			return $result;
		}

		/**
		 *  Checks if array is single or multidimensional
		 *  @param $data array
		 * 	@return boolean
		 * 
		 * */
		protected function is_single($data){
			foreach ($data as  $value) {
				if (is_array($value)){
					return false;
				} 
				else {
					return true;
				}
			}
		}
				
		
		function error(){
            $this->msg='Error. Action not defined';
         }
		
		function ajax($output){
			ob_clean();
			if(is_array($output)){
				echo json_encode($output);

			}
		}
	}