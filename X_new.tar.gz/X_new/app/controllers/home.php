<?php

   namespace X\App\Controllers;

   use X\Sys\Controller;


   class Home extends Controller{
   		

   		public function __construct($params){
   			parent::__construct($params);
            $this->dataView=array(
               'title'=>'Home',
               'name'=>'Kevin');
   			$this->model=new \X\App\Models\mhome();
   			$this->view =new \X\App\Views\vHome($this->dataView, $this->dataTable);
            //var_dump($this->view);
   		}

   		function home(){
   			echo "<hr>";
            $iniTransaction=$this->model->beginTransaction();
            var_dump($iniTransaction);
            echo "<hr>";

            $data=$this->model->getRoles();
            $ultimoID=$this->model->lastInsertId();
            var_dump($ultimoID);
            echo "<hr>";

            $endTransaction=$this->model->endTransaction();
            var_dump($endTransaction);

            
            $this->addData($data);
            echo "<hr>";
            var_dump($data); //Obtenim un array amb l'informació de getRoles de mHome.php

            $this->view->__construct($this->dataView, $this->dataTable);
            $this->view->show();
   		}
   }
