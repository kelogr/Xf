<?php

	namespace X\App\Models;

	use \X\Sys\Model;

	class mHome extends Model{
		public function __construct(){
			parent::__construct();

		}

		/**
		*
		*	Aquesta funció realitza una consulta a la base de
		*	dades per obtenir totes de files i columnes de roles
		*
		**/

		public function getRoles(){
			$sql="SELECT * FROM roles";
			$this->query($sql);
			$res=$this->execute();
			if($res){
				$result=$this->resultset();
							
			}else {$result=null;}
			return $result;
		}
	}