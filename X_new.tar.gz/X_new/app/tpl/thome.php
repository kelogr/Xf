<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Home</title>
</head>
<body>
	<hr>
	<div style="text-align: center;"">
	<h1><?= $this->title; ?></h1>

	<h3><?= $this->name; ?></h3>
	
	
	<table style="margin: auto;">
		<?php for($i=0;$i<count($this->dataTable);$i++){ ?>
			<tr>
			<?php foreach($this->dataTable[$i] as $key=>$value) :?>
				
	        		<td><?= $value; ?></td>
	    	
	    	<?php endforeach; ?>
	    	</tr>
	    <?php } ?>
	</table>
	</div>
	
</body>
</html>